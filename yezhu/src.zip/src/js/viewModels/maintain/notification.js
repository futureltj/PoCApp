define(['ojs/ojcore', 'knockout', 'jquery', 'tfcommon', 'ojs/ojknockout', 'ojs/ojrouter'],
        function (oj, ko, $, common)
        {
            'use strict';

            function NotificationViewModel(params)
            {
                var self = this;
               
            }
            return NotificationViewModel;
        }
);