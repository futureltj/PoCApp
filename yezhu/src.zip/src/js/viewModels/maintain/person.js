define(['ojs/ojcore', 'knockout', 'jquery', 'tfcommon', 'ojs/ojknockout', 'ojs/ojrouter'],
        function (oj, ko, $, common)
        {
            'use strict';

            function PersonViewModel(params)
            {
                var self = this;
               
            }
            return PersonViewModel;
        }
);