define([], function () {
  return {
    appId: 'tf.front',
  
    "rest_base_url": "qiaoxinapi",
    "rest_web_root": "/",
    "page":20,
    appVersion: '1.0',

  }
})



